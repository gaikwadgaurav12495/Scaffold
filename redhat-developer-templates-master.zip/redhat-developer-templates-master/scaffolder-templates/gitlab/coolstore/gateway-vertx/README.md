# Vertx Template

This repository contains the Backstage Template used to create the Kubernetes resources needed to build/deploy a simple vertx application.

## Repository Breakdown

TBD
