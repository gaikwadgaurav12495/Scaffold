# inventory-quarkus
CoolStore Inventory Service with Quarkus.

REST API service written in Quarkus.

Great service.


# Start VSCode with OpenShift DevSpaces

<a href="https://devspaces.apps.rhte.0x74.p1.openshiftapps.com/#https://github.com/coolstore-demo/inventory-quarkus" target="_blank"><img src="https://raw.githubusercontent.com/blues-man/cloud-native-workshop/demo/factory-contribute.svg" alt="Contribute"></a>
