package com.redhat.cloudnative;

import io.quarkus.test.junit.QuarkusIntegrationTest;

@QuarkusIntegrationTest
public class NativeInventoryResourceIT extends InventoryResourceTest {

    // Execute the same tests but in native mode.
}