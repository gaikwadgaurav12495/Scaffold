angular.module("app")
.constant("COOLSTORE_CONFIG", {"API_ENDPOINT":"gateway-vertx-undefined","SECURE_API_ENDPOINT":"gateway-vertx-undefined","SSO_ENABLED":false,"PRODUCT_REFRESH_INTERVAL":5000});
