[![Contribute](https://img.shields.io/static/v1?label=start&message=codingwith%20default%20IDE&logo=eclipseche&color=FDB940&labelColor=525C86)](https://workspaces.openshift.com/#https://github.com/modernizing-java-applications-book/catalog-spring-boot)

[![Contribute](https://img.shields.io/static/v1?label=start&message=coding%20with%20vscode%20IDE&logo=eclipseche&color=FDB940&labelColor=525C86)](https://workspaces.openshift.com/#https://github.com/modernizing-java-applications-book/catalog-spring-boot?che-editor=che-incubator/che-code/insiders)

[![Contribute](https://img.shields.io/static/v1?label=start&message=coding%20with%20IntelliJ%20IDE&logo=eclipseche&color=FDB940&labelColor=525C86)](https://workspaces.openshift.com/#https://github.com/modernizing-java-applications-book/catalog-spring-boot?che-editor=che-incubator/che-idea/next)

[![Contribute](https://img.shields.io/static/v1?label=start&message=coding%20ephemeral%20(faster)&logo=eclipseche&color=FDB940&labelColor=525C86)](https://workspaces.openshift.com/#https://github.com/modernizing-java-applications-book/catalog-spring-boot?storageType=ephemeral)


<a href="https://devspaces.apps.sandbox.x8i5.p1.openshiftapps.com/f?url=https://github.com/modernizing-java-applications-book/catalog-spring-boot&policies.create=peruser" target="_blank"><img src="https://raw.githubusercontent.com/blues-man/cloud-native-workshop/demo/factory-contribute.svg" alt="Contribute"></a>
