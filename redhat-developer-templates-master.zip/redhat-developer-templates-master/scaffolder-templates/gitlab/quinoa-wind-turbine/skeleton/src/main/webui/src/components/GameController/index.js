
export { default } from './GameController';

