# Go backend for Vote app

This repository contains the Backstage Template used to create the Kubernetes resources needed to build/deploy the Python Frontend for the Vote app.

