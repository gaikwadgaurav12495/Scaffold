# Voting app for Tekton Pipeline UI

![Vote App Dev view](https://raw.githubusercontent.com/blues-man/vote-app-gitops/main/images/topology-vote-app-dev.png)


## Developer Workspace

[![Contribute](https://raw.githubusercontent.com/blues-man/cloud-native-workshop/demo/factory-contribute.svg)](https://devspaces.apps.rhte.0x74.p1.openshiftapps.com/f?url=https://github.com/blues-man/pipelines-vote-ui&policies.create=peruser)

